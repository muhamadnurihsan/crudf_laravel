@extends('layout.app')
@section('title', 'dashboard')
@section('content')
    <p>Dashboard</p>
@endsection