
<div class="table-responsive">
    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
        <thead>
            <tr>
                <th>No</th>
                <th>Nama Siswa</th>
                <th>Kelas</th>
                <th>Status</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $no=1; ?>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>                       
            <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($data->name); ?></td>
                <td><?php echo e($data->class); ?></td>
                <td><?php echo e($data->status); ?></td>
                <td>
                    <button class="btn btn-warning" onclick="#">Edit</button>
                    <button class="btn btn-danger" onclick="#">Hapus</button>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>

<script src="<?php echo e(asset('template/vendor/datatables/jquery.dataTables.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/vendor/datatables/dataTables.bootstrap4.min.js')); ?>"></script>
<script src="<?php echo e(asset('template/js/demo/datatables-demo.js')); ?>"></script><?php /**PATH C:\code\laravel\crudf-laravel\resources\views/read.blade.php ENDPATH**/ ?>