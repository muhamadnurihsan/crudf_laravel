<form action="javascript:void(0)" id="exampleForm" name="exampleForm" method="POST">
    <input type="hidden" name="id" id="id">
    <div class="form-group">
        <label>Nama Siswa</label>
        <input type="text" class="form-control" id="name" name="name" value="<?php echo e($students->name); ?>" placeholder="Nama Siswa">
    </div>
    <div class="form-group">
        <label>Kelas</label>
        <select class="form-control" id="class" name="class">
            <option value="" selected disabled>Pilih Kelas</option>
            <?php $__currentLoopData = $kelas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $class): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($class); ?>" <?php echo e($students->class == $class ? 'selected' : ''); ?>><?php echo e($class); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    <div class="col-sm-offset-2 col-sm-10"><br/>
        <button type="button" class="btn btn-secondary" data-dismiss="modal" onclick="closeX()">Kembali</button>
        <button class="btn btn-primary" onClick="update(<?php echo e($students->id); ?>)">Update</button>
    </div>
</form><?php /**PATH C:\code\laravel\crudf-laravel\resources\views/students/edit.blade.php ENDPATH**/ ?>