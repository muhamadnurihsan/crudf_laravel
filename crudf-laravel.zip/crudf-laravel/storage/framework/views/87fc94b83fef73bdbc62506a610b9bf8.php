
<?php $__env->startSection('title', 'dashboard'); ?>
<?php $__env->startSection('content'); ?>
    <p>Dashboard</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\code\laravel\crudf-laravel\resources\views/dashboard.blade.php ENDPATH**/ ?>